function Punishments() {
  return <div>Punishments</div>
}

export default Punishments